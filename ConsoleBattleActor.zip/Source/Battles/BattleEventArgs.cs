﻿using PokemonGeneration1.Source.PokemonData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokemonGeneration1.Source.Battles
{
    public class BattleEventArgs : EventArgs 
    {
        public Battle thisBattle;
    }
}
