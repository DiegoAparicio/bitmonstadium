﻿namespace PokemonGeneration1.Source.PokemonData
{
    public enum Status
    {
        Null,
        Burn,
        Freeze,
        Paralysis,
        Poison,
        BadlyPoisoned,
        Sleep,
        Fainted
    }
}
