﻿using PokemonGeneration1.Source.Moves.Reflexive;
using PokemonGeneration1.Source.Moves.Transitive.Attack.MultiTurn;
using PokemonGeneration1.Source.Moves.Transitive.Attack.OneTurnMultiHit;
using PokemonGeneration1.Source.Moves.Transitive.Attack.OneTurnOneHit;
using PokemonGeneration1.Source.Moves.Transitive.Status;
using System;

namespace PokemonGeneration1.Source.Moves
{
    public static class MoveFactory
    {
        public static Move CreateRandomMoveForMetronome()
        {
            Move move = null;
            while (move == null)
            {
                int rando = new Random().Next(1, 17);
                
                    move = Create(rando);
            }
            return move;
        }


        public static Move Create(int moveIndex)
        {
            switch (moveIndex)
            {
                case 1: return new Ember();
                case 2: return new FireFang();
                case 3: return new FireSping();
                case 4: return new FlameThrower();
                case 5: return new IceShard();
                case 6: return new FrostBreath();
                case 7: return new PowderSnow();
                case 8: return new Hypothermia();
                case 9: return new WaterGun();
                
                case 10: return new PoisonGun();
                case 11: return new Bubble();
                case 12: return new WaterFall();
                case 13: return new ThunderShock();
                case 14: return new Spark();
                case 15: return new ChargeBeam();
                case 16: return new VoltSwitch();
                
                default: return null;
            }
        }
    }
}
