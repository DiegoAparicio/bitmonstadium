﻿using PokemonGeneration1.Source.PokemonData;
using System;

namespace PokemonStadiumConsoleApp
{
    public static class SelectPokemon
    {
        public static Pokemon Choose()
        {
            int input = int.MinValue;

            while (input < 1 || input > 10)
            {
                Console.Clear();
                Display149Pokemon();
                Console.Write("Enter selection: ");
                while (!Int32.TryParse(Console.ReadLine(), out input))
                {
                    Console.Clear();
                    Display149Pokemon();
                    Console.Write("Enter selection: ");
                }
                
            }

            Console.Clear();
            return RentalPokemonFactory.PrimeCup(input);
        }

       

        private static void Display149Pokemon()
        {
            string line;
            for (int i = 1; i < 11; i++)
            {
                line = Display.LeftJustify(i + " | " + SpeciesData.Names[i], 11);

                Console.WriteLine(line);
            }
        }
    }
}
